//Currency Converter Project
//Class: UMGC CMSC 495
//Author: Danny Padro, Shawn Kratochvil, Mike Schaffner
//Date:  10 OCT 2021
//Professor: Dr Hung Dao
//Purpose:  Create an application that converts one currency to another
//API File created following instructions on Exchange Rate API website.
//Example code used and modified for this project

/* Record of Changes

Revision 1, 26 Sep 2021, API File created with source code documentation
                         from Exchange Rate API website.  Pair word was added
                         to create use with selected currencies.
Revision Author: Shawn Kratochvil

*/

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;




public class API {
	static String req_result, conversionRate;
	
	static String url_str;
	API()
	{
		url_str = "https://v6.exchangerate-api.com/v6/0689f6bce85c420be737546a/pair/";
	}
	String getURL()
	{
		return url_str;
	}
	void setURL(String a)
	{
		url_str = a;
	}
	void clearURL()
	{
		url_str = "https://v6.exchangerate-api.com/v6/0689f6bce85c420be737546a/pair/";
	}
	
	 
}
