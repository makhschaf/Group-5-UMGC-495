import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;




public class API {
	static String req_result, conversionRate;
	
	static String url_str;
	API()
	{
		url_str = "https://v6.exchangerate-api.com/v6/0689f6bce85c420be737546a/pair/";
	}
	String getURL()
	{
		return url_str;
	}
	void setURL(String a)
	{
		url_str = a;
	}
	void clearURL()
	{
		url_str = "https://v6.exchangerate-api.com/v6/0689f6bce85c420be737546a/pair/";
	}
	
	 
}